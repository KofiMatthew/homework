# trainScheduler
This is a basic tool for entering data into a database, retrieving that data, and making some basic time calculations with moment.js.